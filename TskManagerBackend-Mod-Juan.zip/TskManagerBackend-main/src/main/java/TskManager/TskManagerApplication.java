package TskManager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class TskManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(TskManagerApplication.class, args);
	}
        

}
