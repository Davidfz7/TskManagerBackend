package TskManager.Exceptions;

public class ErrorMesage {
    //espacio para ErrorMessage, No utilizado, Borrar
}
